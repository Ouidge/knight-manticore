#!/usr/bin/env node

/**
 * Convertit un export JSON d'acteur du système Knight (Foundry VTT) en Markdown.
 *
 * Utilisation :
 *   node convert-foundry-knight.mjs export.json
 *   node convert-foundry-knight.mjs export.json fiche.md
 *
 * Sans second argument, le fichier est créé à côté du JSON.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { effectPresentation } from "./effect-normalization.mjs";

const inputPath = process.argv[2];
if (!inputPath || ["-h", "--help"].includes(inputPath)) {
  console.log("Usage : node convert-foundry-knight.mjs <export.json> [fiche.md]");
  process.exit(inputPath ? 0 : 1);
}

const absoluteInput = path.resolve(inputPath);
const actor = JSON.parse(fs.readFileSync(absoluteInput, "utf8"));
const mjOutputArgument = process.argv.find((argument) => argument.startsWith("--mj-output="));
const summaryOutputArgument = process.argv.find((argument) => argument.startsWith("--summary-output="));
const outputPath = path.resolve(
  process.argv[3] && !process.argv[3].startsWith("--")
    ? process.argv[3]
    : path.join(path.dirname(absoluteInput), `${safeFilename(actor.name || "personnage")}.md`),
);

const DOMAIN_CHARACTERISTICS = {
  chair: ["deplacement", "force", "endurance"],
  bete: ["hargne", "combat", "instinct"],
  machine: ["tir", "savoir", "technique"],
  dame: ["aura", "parole", "sangFroid"],
  masque: ["discretion", "dexterite", "perception"],
};

const LABELS = {
  chair: "Chair",
  bete: "Bête",
  machine: "Machine",
  dame: "Dame",
  masque: "Masque",
  deplacement: "Déplacement",
  force: "Force",
  endurance: "Endurance",
  hargne: "Hargne",
  combat: "Combat",
  instinct: "Instinct",
  tir: "Tir",
  savoir: "Savoir",
  technique: "Technique",
  aura: "Aura",
  parole: "Parole",
  sangFroid: "Sang-froid",
  discretion: "Discrétion",
  dexterite: "Dextérité",
  perception: "Perception",
};

const system = actor.system ?? {};
const items = Array.isArray(actor.items) ? actor.items : [];
const xpHistory = Object.values(system.progression?.experience?.depense?.liste ?? {});

function safeFilename(value) {
  return String(value).replace(/[<>:"/\\|?*]/g, "-").trim() || "personnage";
}

function number(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function escapeCell(value) {
  return String(value ?? "—").replaceAll("|", "\\|").replace(/\s*\n\s*/g, " ");
}

function htmlToMarkdown(html = "") {
  return String(html)
    .replace(/<\s*br\s*\/?\s*>/gi, "\n")
    .replace(/<\/(p|div|li|h[1-6])>/gi, "\n")
    .replace(/<li[^>]*>/gi, "- ")
    .replace(/<(strong|b)[^>]*>(.*?)<\/\1>/gis, "**$2**")
    .replace(/<(em|i)[^>]*>(.*?)<\/\1>/gis, "*$2*")
    .replace(/<[^>]+>/g, "")
    .replaceAll("&nbsp;", " ")
    .replaceAll("&rsquo;", "’")
    .replaceAll("&lsquo;", "‘")
    .replaceAll("&ldquo;", "“")
    .replaceAll("&rdquo;", "”")
    .replaceAll("&amp;", "&")
    .replaceAll("&quot;", '"')
    .replaceAll("&eacute;", "é")
    .replaceAll("&Eacute;", "É")
    .replaceAll("&agrave;", "à")
    .replaceAll("&Agrave;", "À")
    .replaceAll("&acirc;", "â")
    .replaceAll("&Acirc;", "Â")
    .replaceAll("&ecirc;", "ê")
    .replaceAll("&egrave;", "è")
    .replaceAll("&euml;", "ë")
    .replaceAll("&icirc;", "î")
    .replaceAll("&iuml;", "ï")
    .replaceAll("&ccedil;", "ç")
    .replaceAll("&ocirc;", "ô")
    .replaceAll("&ucirc;", "û")
    .replaceAll("&ugrave;", "ù")
    .replaceAll("&oelig;", "œ")
    .replaceAll("&ndash;", "–")
    .replaceAll("&laquo;", "«")
    .replaceAll("&raquo;", "»")
    .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function normalizeKey(value = "") {
  return String(value)
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .replace(/[^a-z0-9]/gi, "")
    .toLowerCase();
}

function progressionBonus(key) {
  const wanted = normalizeKey(key);
  return xpHistory
    .filter((entry) => normalizeKey(entry?.nom) === wanted)
    .reduce((sum, entry) => sum + number(entry?.bonus), 0);
}

function domainValue(domain) {
  return number(system.aspects?.[domain]?.base) + progressionBonus(domain);
}

function characteristicValue(domain, characteristic) {
  const base = number(system.aspects?.[domain]?.caracteristiques?.[characteristic]?.base);
  return base + progressionBonus(characteristic);
}

function selectedModuleLevel(item) {
  const nameLevel = item.name?.match(/(?:niv(?:eau)?\.?\s*)(\d+)/i)?.[1];
  return Math.max(number(nameLevel), number(item.system?.niveau?.value));
}

function moduleOd(item, domain, characteristic) {
  const level = selectedModuleLevel(item);
  const details = item.system?.niveau?.details ?? {};
  const selected = details[`n${level}`] ?? details[`n${item.system?.niveau?.value}`];
  return number(selected?.overdrives?.aspects?.[domain]?.[characteristic]);
}

function overdriveValue(domain, characteristic) {
  const base = number(
    system.aspects?.[domain]?.caracteristiques?.[characteristic]?.overdrive?.base,
  );
  const moduleValues = items
    .filter((item) => item.type === "module")
    .map((item) => moduleOd(item, domain, characteristic));
  return Math.max(base, ...moduleValues);
}

function maxCharacteristic(domain, withOverdrive = false) {
  return Math.max(
    ...DOMAIN_CHARACTERISTICS[domain].map((characteristic) =>
      characteristicValue(domain, characteristic) +
      (withOverdrive ? overdriveValue(domain, characteristic) : 0),
    ),
  );
}

function traitModifier(type, path) {
  return items
    .filter((item) => item.type === type && item.system?.type === "standard")
    .reduce((sum, item) => {
      let value = item.system?.[type === "avantage" ? "bonus" : "malus"];
      for (const key of path) value = value?.[key];
      return sum + number(value);
    }, 0);
}

function actorModifier(stat) {
  const bonuses = Object.values(system[stat]?.bonus ?? {}).reduce(
    (sum, value) => sum + number(value),
    0,
  );
  const penalties = Object.values(system[stat]?.malus ?? {}).reduce(
    (sum, value) => sum + number(value),
    0,
  );
  return bonuses - penalties;
}

function weaponFlatModifier(statistic) {
  let total = 0;

  for (const item of items.filter((entry) => entry.type === "arme" && entry.system?.equipped)) {
    const data = item.system ?? {};
    let effects = [];

    if (data.type === "contact") {
      if (!data.options2mains?.has || data.options2mains?.actuel === "1main") {
        effects.push(...(data.effets?.raw ?? []), ...(data.effets?.custom ?? []));
      } else {
        effects.push(...(data.effets2mains?.raw ?? []), ...(data.effets2mains?.custom ?? []));
      }
      effects.push(
        ...(data.structurelles?.raw ?? []),
        ...(data.structurelles?.custom ?? []),
        ...(data.ornementales?.raw ?? []),
        ...(data.ornementales?.custom ?? []),
      );
    } else if (data.type === "distance") {
      effects.push(
        ...(data.effets?.raw ?? []),
        ...(data.effets?.custom ?? []),
        ...(data.distance?.raw ?? []),
        ...(data.distance?.custom ?? []),
      );
      if (data.optionsmunitions?.has) {
        const ammunition = data.optionsmunitions?.liste?.[data.optionsmunitions?.actuel] ?? {};
        effects.push(...(ammunition.raw ?? []), ...(ammunition.custom ?? []));
      }
    }

    for (const effect of effects) {
      if (typeof effect === "object" && effect?.other?.cdf && statistic === "cdf") {
        total += number(effect.other.cdf);
        continue;
      }
      const [key, rawValue] = String(effect).split(" ");
      const value = number(rawValue);
      if (statistic === "defense") {
        if (key === "defense") total += value;
        if (key === "boucliergrave") total += 1;
        if (key === "massive") total -= 1;
      }
      if (statistic === "reaction") {
        if (key === "reaction") total += value;
        if (key === "protectionarme") total += 2;
      }
      if (statistic === "cdf") {
        if (key === "cdf") total += value;
        if (key === "armuregravee") total += 2;
      }
    }
  }

  return total;
}

function styleModifiers(style = "standard") {
  const result = { defense: 0, reaction: 0 };
  if (style === "defensif") result.defense += 2;
  if (style === "acouvert") result.reaction += 2;
  if (["agressif", "puissant"].includes(style)) {
    result.defense -= 2;
    result.reaction -= 2;
  }
  return result;
}

function isFree(value) {
  return value === true || String(value).toLowerCase() === "true";
}

function experienceSpent() {
  return xpHistory.reduce((sum, entry) => sum + number(entry?.cout), 0);
}

function glorySpent() {
  let spent = 0;

  for (const item of items) {
    if (item.type === "armure") {
      const longbow = item.system?.evolutions?.special?.longbow ?? {};
      for (const evolution of Object.values(longbow)) {
        if (evolution?.applied && !isFree(evolution?.gratuit)) {
          spent += number(evolution?.value);
        }
      }
      continue;
    }

    if (["arme", "cyberware"].includes(item.type)) {
      if (!isFree(item.system?.gratuit)) spent += number(item.system?.prix);
      continue;
    }

    if (item.type !== "module" || item.system?.isLion) continue;

    const maximumLevel = number(item.system?.niveau?.value);
    for (let level = 1; level <= maximumLevel; level += 1) {
      const data = item.system?.niveau?.details?.[`n${level}`] ?? {};
      if (!data.ignore && !isFree(data.gratuit)) spent += number(data.prix);
    }
  }

  for (const entry of Object.values(system.progression?.gloire?.depense?.autre ?? {})) {
    if (!isFree(entry?.gratuit)) spent += number(entry?.cout);
  }

  return spent;
}

function formatDice(stat = {}) {
  const dice = number(stat.dice);
  const fixed = number(stat.fixe);
  if (!dice && !fixed) return "—";
  return `${dice ? `${dice}D6` : ""}${dice && fixed ? " + " : ""}${fixed || ""}`;
}

function weaponBaseName(name = "") {
  return name.replace(/\s+-\s+(contact|tir|missiles?|roquettes?)$/i, "").trim();
}

function slugify(value = "") {
  return value
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[’']/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function quartzNoteSlug(value = "") {
  // Reproduit slugifyPath() de Quartz v5 pour un nom de note : les accents,
  // apostrophes et parenthèses sont conservés ; seuls les espaces et quelques
  // caractères réservés sont transformés ou retirés.
  return String(value)
    .replace(/\s/g, "-")
    .replace(/&/g, "-and-")
    .replace(/%/g, "-percent")
    .replace(/\?/g, "")
    .replace(/#/g, "")
    .replace(/[<>:"|*]/g, "")
    .toLowerCase();
}

function weaponMode(name = "") {
  return name.match(/\s+-\s+(.+)$/)?.[1] ?? "Attaque";
}

function weaponUrl(name) {
  return `https://knight-jdr-systeme.fr/fr/weapon/${slugify(weaponBaseName(name))}/`;
}

function armorUrl(name) {
  return `https://knight-jdr-systeme.fr/fr/armour/${slugify(name)}/`;
}

function rangeAbbreviation(range = "") {
  const normalized = normalizeKey(range);
  const abbreviations = {
    contact: "C",
    distancemelee: "DM",
    courte: "CT",
    moyenne: "M",
    longue: "L",
    lointaine: "LT",
  };
  return abbreviations[normalized] ?? String(range || "—").toUpperCase();
}

function checkBoxes(count) {
  return Array.from(
    { length: Math.max(0, Math.min(number(count), 20)) },
    () => '<i class="knight-check-box" aria-hidden="true"></i>',
  ).join("");
}

function moduleUrl(name) {
  return `https://knight-jdr-systeme.fr/fr/module/${slugify(moduleFamily(name))}/`;
}

function rangeHelpUrl(range) {
  return `https://ouidge.github.io/knight-manticore/aides-de-jeu/port%C3%A9es/${range}`;
}

function grenadeModuleBonus(grenadeKey, statistic) {
  return items
    .filter((item) => item.type === "module")
    .reduce((sum, item) => {
      const data = selectedModuleData(item);
      if (!data.bonus?.has || !data.bonus?.grenades?.has) return sum;
      return sum + number(data.bonus.grenades?.liste?.[grenadeKey]?.[statistic]?.dice);
    }, 0);
}

function damageViolenceBonuses(effects = [], extra = {}) {
  const damage = [];
  const violence = [];

  for (const effect of effects) {
    if (typeof effect !== "string") continue;
    const normalized = normalizeKey(effect);
    const continuous = effect.match(/d[eé]g[aâ]ts\s*continus\s+(\d+)/i);

    if (normalized === "faucheusegravee") damage.push("+1D6 (Faucheuse gravée)");
    if (normalized === "meurtrier") damage.push("+2D6 (Meurtrier)");
    if (normalized === "destructeur") damage.push("+2D6 (Destructeur)");
    if (normalized === "silencieux") {
      const discretion = characteristicValue("masque", "discretion") + overdriveValue("masque", "discretion");
      if (discretion) damage.push(`+${discretion} (Silencieux — surprise, invisibilité, Ghost ou Changeling)`);
    }
    if (normalized === "surmesure") {
      const combat = characteristicValue("bete", "combat") + overdriveValue("bete", "combat");
      if (combat) damage.push(`+${combat} (Sur mesure)`);
    }
    if (normalized === "ultraviolence") {
      violence.push("+2D6 (bande, Chair < 10)");
    }
    if (normalized === "fureur") violence.push("+4D6 (bande, Chair > 10)");
    if (continuous) damage.push(`Dégâts continus ${continuous[1]}`);
  }

  const extraDamage = number(extra.damage);
  const extraViolence = number(extra.violence);
  if (extraDamage) damage.push(`+${extraDamage}D6 (module Grenades intelligentes)`);
  if (extraViolence) violence.push(`+${extraViolence}D6 (module Grenades intelligentes)`);

  return {
    damage: [...new Set(damage)],
    violence: [...new Set(violence)],
  };
}

function bonusLinesHtml(bonuses = []) {
  if (!bonuses.length) return "";
  return `<small class="knight-dv-bonus">${bonuses.map((bonus) => `<span>${escapeHtml(bonus)}</span>`).join("")}</small>`;
}

function precomputedDamage(stat = {}, effects = [], options = {}) {
  if (stat.variable?.has) {
    return { formula: "Variable", details: ["Selon le réglage de l’arme"] };
  }

  let dice = number(stat.dice);
  let fixed = number(stat.fixe);
  const details = [];
  const normalizedEffects = new Set(
    effects.filter((effect) => typeof effect === "string").map(normalizeKey),
  );

  if (options.contact) {
    const force = characteristicValue("chair", "force");
    const forceOverdrive = overdriveValue("chair", "force");
    const overdriveDamage = forceOverdrive * 3;
    const isWeighted = normalizedEffects.has("leste");
    const forceDamage = force * (isWeighted ? 2 : 1);
    fixed += forceDamage + overdriveDamage;
    if (force) details.push(isWeighted ? `Force ${force} × 2 (Lesté)` : `Force ${force}`);
    if (overdriveDamage) details.push(`OD Force +${overdriveDamage}`);
  }

  if (normalizedEffects.has("surmesure")) {
    const combat = characteristicValue("bete", "combat") + overdriveValue("bete", "combat");
    fixed += combat;
    if (combat) details.push(`Sur mesure +${combat}`);
  }

  if (normalizedEffects.has("faucheusegravee")) {
    dice += 1;
    details.push("Faucheuse gravée +1D6");
  }

  const extraDice = number(options.extraDice);
  if (extraDice) {
    dice += extraDice;
    details.push(`Module +${extraDice}D6`);
  }

  return { formula: formatDice({ dice, fixe: fixed }), details };
}

function precomputedDamageHtml(calculation, conditionalBonuses = []) {
  const detail = calculation.details?.length
    ? `<small class="knight-damage-calculation-detail">${calculation.details.map(escapeHtml).join(" · ")}</small>`
    : "";
  return `<strong class="knight-damage-calculation">${escapeHtml(calculation.formula)}</strong>${detail}${bonusLinesHtml(conditionalBonuses)}`;
}

function conditionalDamageBonuses(bonuses = []) {
  return bonuses.filter((bonus) =>
    /\((?:Meurtrier|Destructeur|Silencieux\b)|^Dégâts continus\b/i.test(bonus),
  );
}

function effectsHtml(effects = [], separator = ", ") {
  const rendered = effects.map(effectPresentation).filter(Boolean).map(({ label, noteTitle }) => {
    if (!noteTitle) return escapeHtml(label);
    // Quartz ajoute lui-même le préfixe du site GitHub Pages (`/knight-manticore`).
    // Le conserver ici produirait un chemin doublé après le rendu.
    const href = `/aides-de-jeu/effets/${quartzNoteSlug(noteTitle)}`;
    return `<a class="internal knight-effect-link" href="${href}">${escapeHtml(label)}</a>`;
  });
  return rendered.join(separator) || "—";
}

function effectsMarkdown(effects = [], separator = ", ") {
  const rendered = effects.map(effectPresentation).filter(Boolean).map(({ label, noteTitle }) => {
    if (!noteTitle) return label;
    return `[${label}](/aides-de-jeu/effets/${quartzNoteSlug(noteTitle)})`;
  });
  return rendered.join(separator) || "—";
}

function arsenalSection(groups) {
  const grenades = system.combat?.grenades ?? {};
  if (!groups.size && number(grenades.quantity?.max) <= 0) return "";
  const lines = [
    '<h3 class="knight-equipment-title">Arsenal</h3>',
    '<table class="knight-arsenal-table"><thead><tr><th>Arme</th><th>Portée</th><th>Dégâts</th><th>Violence</th><th>Effets</th><th>Dégâts PJ</th></tr></thead>',
  ];

  for (const [baseName, group] of groups) {
    lines.push('<tbody class="knight-weapon-group">');
    const modes = group
      .map((weapon) => weaponMode(weapon.name))
      .filter((mode) => mode !== "Attaque");
    const modesLabel = modes.length > 1
      ? `<small class="knight-weapon-mode">${escapeHtml(modes.join(" / "))}</small>`
      : "";

    for (const [index, weapon] of group.entries()) {
      const effects = [
        ...(weapon.system?.effets?.raw ?? []),
        ...(weapon.system?.effets?.custom ?? []),
        ...(weapon.system?.distance?.raw ?? []),
        ...(weapon.system?.distance?.custom ?? []),
        ...(weapon.system?.structurelles?.raw ?? []),
        ...(weapon.system?.structurelles?.custom ?? []),
        ...(weapon.system?.ornementales?.raw ?? []),
        ...(weapon.system?.ornementales?.custom ?? []),
      ];
      const mode = weaponMode(weapon.name);
      const range = rangeAbbreviation(weapon.system?.portee);
      const rangeAndMode = mode === "Attaque" ? range : `${mode} · ${range}`;
      const bonuses = damageViolenceBonuses(effects);
      const damageCell = escapeHtml(formatDice(weapon.system?.degats));
      const violenceCell = `${escapeHtml(formatDice(weapon.system?.violence))}${bonusLinesHtml(bonuses.violence)}`;
      const calculatedDamage = precomputedDamage(weapon.system?.degats, effects, {
        contact: normalizeKey(weapon.system?.type) === "contact" || normalizeKey(weapon.system?.portee) === "contact",
      });
      lines.push(
        `<tr>${index === 0 ? `<td rowspan="${group.length}"><a href="${weapon.arsenalUrl ?? weaponUrl(baseName)}">${escapeHtml(baseName)} ↗</a>${modesLabel}</td>` : ""}<td>${escapeHtml(rangeAndMode)}</td><td class="knight-damage-cell">${damageCell}</td><td class="knight-damage-cell">${violenceCell}</td><td class="knight-effects-cell">${effectsHtml(effects)}</td><td class="knight-calculated-damage-cell">${precomputedDamageHtml(calculatedDamage, conditionalDamageBonuses(bonuses.damage))}</td></tr>`,
      );
    }
    lines.push("</tbody>");
  }

  const grenadeLabels = {
    antiblindage: "Grenade antiblindage",
    explosive: "Grenade explosive",
    flashbang: "Grenade flashbang",
    iem: "Grenade IEM",
    shrapnel: "Grenade shrapnel",
  };
  if (number(grenades.quantity?.max) > 0) {
    lines.push('<tbody class="knight-grenade-group">');
    for (const [index, [key, grenade]] of Object.entries(grenades.liste ?? {}).entries()) {
      const effects = [
        ...(grenade.effets?.raw ?? []),
        ...(grenade.effets?.custom ?? []),
      ];
      const moduleBonus = {
        damage: grenadeModuleBonus(key, "degats"),
        violence: grenadeModuleBonus(key, "violence"),
      };
      const bonuses = damageViolenceBonuses(effects, moduleBonus);
      const damageCell = escapeHtml(formatDice(grenade.degats));
      const violenceCell = `${escapeHtml(formatDice(grenade.violence))}${bonusLinesHtml(bonuses.violence)}`;
      const calculatedDamage = precomputedDamage(grenade.degats, effects, { extraDice: moduleBonus.damage });
      lines.push(
        `<tr class="knight-grenade-row${index === 0 ? " knight-first-grenade" : ""}"><td><a href="https://knight-jdr-systeme.fr/fr/weapon/grenade-intelligente/">${escapeHtml(grenade.custom ? grenade.label : grenadeLabels[key] ?? `Grenade ${key}`)} ↗</a></td><td>CT</td><td class="knight-damage-cell">${damageCell}</td><td class="knight-damage-cell">${violenceCell}</td><td class="knight-effects-cell">${effectsHtml(effects)}</td><td class="knight-calculated-damage-cell">${precomputedDamageHtml(calculatedDamage, conditionalDamageBonuses(bonuses.damage))}</td></tr>`,
      );
    }
    lines.push("</tbody>");
  }

  lines.push("</table>");
  lines.push(
    `<p class="knight-range-legend"><strong>Portées :</strong> <a href="${rangeHelpUrl("contact")}"><strong>C — Contact</strong> : distance de mêlée</a> · <a href="${rangeHelpUrl("courte")}"><strong>CT — Courte</strong> : 2–15 m</a> · <a href="${rangeHelpUrl("moyenne")}"><strong>M — Moyenne</strong> : 15–50 m</a> · <a href="${rangeHelpUrl("longue")}"><strong>L — Longue</strong> : 50–300 m</a> · <a href="${rangeHelpUrl("lointaine")}"><strong>LT — Lointaine</strong> : plus de 300 m</a></p>`,
  );
  return lines.join("\n");
}

function meaningfulItem(item) {
  const description = htmlToMarkdown(item.system?.description);
  if (description) return true;
  if (item.type === "arme") {
    return Boolean(
      number(item.system?.degats?.dice) ||
        number(item.system?.degats?.fixe) ||
        number(item.system?.violence?.dice) ||
        number(item.system?.violence?.fixe),
    );
  }
  return !["Avantage", "Inconvénient", "Arme", "Capacité héroïque"].includes(item.name);
}

function mechanicalSummary(item) {
  const source = item.type === "avantage" ? item.system?.bonus : item.system?.malus;
  if (!source) return "";
  const effects = [];
  const sign = item.type === "avantage" ? "+" : "−";
  if (number(source.sante)) effects.push(`${sign}${number(source.sante)} PS`);
  if (number(source.espoir)) effects.push(`${sign}${number(source.espoir)} PEs`);
  if (number(source.initiative?.dice)) {
    effects.push(`${sign}${number(source.initiative.dice)}D6 en initiative`);
  }
  if (number(source.initiative?.fixe)) {
    effects.push(`${sign}${number(source.initiative.fixe)} en initiative`);
  }
  return effects.join(" ; ");
}

function traitSection(title, selectedItems) {
  if (!selectedItems.length) return "";
  const content = selectedItems
    .map((item) => {
      const description = htmlToMarkdown(item.system?.description);
      const effect = mechanicalSummary(item);
      return [
        '<section class="knight-trait">',
        `<h3>${escapeHtml(item.name)}</h3>`,
        `<div class="knight-trait-description">${markdownishHtml(description || effect || "—")}</div>`,
        "</section>",
      ]
        .filter(Boolean)
        .join("\n");
    })
    .join("\n\n");
  return `<section class="knight-traits"><h2>${escapeHtml(title)}</h2>\n${content}\n</section>`;
}

function contactsSection(contacts, visibilityClass = "") {
  if (!contacts.length) return "";
  const rows = contacts
    .map((contact) => {
      const description = htmlToMarkdown(contact.system?.description);
      return `<li><strong>${escapeHtml(contact.name || "Contact sans nom")}</strong>${description ? ` <span>— ${escapeHtml(description.replace(/\s+/gu, " ").trim())}</span>` : ""}</li>`;
    })
    .join("\n");
  return [
    `<section class="knight-contacts knight-domain ${visibilityClass}">`,
    "<h3>Contacts</h3>",
    `<ul>${rows}</ul>`,
    "</section>",
  ].join("\n");
}

function armorEvolutionsSection(armorItem) {
  const evolutions = armorItem?.system?.evolutions ?? {};
  const acquired = [];

  for (const evolution of Object.values(evolutions.liste ?? {})) {
    if (!evolution?.applied) continue;
    acquired.push({
      label: `${number(evolution.value)} PG`,
      description: htmlToMarkdown(evolution.description || ""),
    });
  }

  for (const [family, levels] of Object.entries(evolutions.special ?? {})) {
    for (const evolution of Object.values(levels ?? {})) {
      if (!evolution?.applied) continue;
      const familyLabel = family.replace(/^./u, (character) => character.toLocaleUpperCase("fr"));
      acquired.push({
        label: `${familyLabel} · ${number(evolution.value)} PG`,
        description: htmlToMarkdown(evolution.description || ""),
      });
    }
  }

  if (!acquired.length) return "";
  const rows = acquired
    .map(({ label, description }) => `<tr><th>${escapeHtml(label)}</th><td>${markdownishHtml(description || "Évolution acquise")}</td></tr>`)
    .join("\n");
  return `<section class="knight-armor-evolutions"><h3>Évolutions acquises</h3><table><tbody>${rows}</tbody></table></section>`;
}

// Use the character's selected values, never the catalogue or evolution snapshots.
function armorCapabilitiesSection(armorItem) {
  const selected = armorItem?.system?.capacites?.selected ?? {};
  const labels = { aucune: "Aucune action", aucun: "Aucune action", toutes: "Toutes les actions", deplacement: "Action de déplacement", deplacement6Sec: "Action de déplacement / 6 secondes", combat: "Action de combat", tour: "Un tour", tour6Sec: "Un tour / 6 secondes", contact: "Contact", distance: "Distance", base: "Simple", detaille: "Détaillé", mecanique: "Mécanique", prolonger: "Prolongation", minute: "Hors conflit" };
  const label = (value) => labels[value] ?? value;
  const entries = [];
  for (const [key, capability] of Object.entries(selected)) {
    if (!capability || typeof capability !== "object") continue;
    const rows = [];
    let supplementalHtml = "";
    const add = (name, value) => {
      if (value !== undefined && value !== null && value !== "") rows.push(`<p><strong>${escapeHtml(name)} :</strong> ${escapeHtml(value)}</p>`);
    };
    const addHtml = (name, value) => {
      if (value !== undefined && value !== null && value !== "") rows.push(`<p><strong>${escapeHtml(name)} :</strong> ${value}</p>`);
    };
    const fields = (value, unit = "") => {
      if (value == null) return "";
      if (typeof value !== "object") return `${label(value)}${unit}`;
      if (value.min != null && value.max != null) return `${value.min} à ${value.max}${unit}`;
      return Object.entries(value).filter(([, v]) => typeof v === "string" || typeof v === "number")
        .map(([k, v]) => `${k === "tour" ? "En conflit" : label(k)} : ${label(v)}${unit}`).join(" · ");
    };
    const table = (headers, tableRows, extraClass = "") => {
      const head = headers.map((header) => `<th>${escapeHtml(header)}</th>`).join("");
      const body = tableRows.map((cells) => `<tr>${cells.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("");
      return `<div class="knight-capability-table-wrap"><table class="knight-capability-table ${extraClass}"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
    };
    const detailedKeys = new Set(["nanoc", "mechanic", "longbow", "borealis", "warlord"]);
    if (!detailedKeys.has(key)) {
      add("Activation", fields(capability.activation));
      add("Durée", capability.duree);
      add(
        "Énergie",
        key === "goliath" && typeof capability.energie === "number"
          ? `${capability.energie} PE par mètre gagné`
          : fields(capability.energie, " PE"),
      );
      if (typeof capability.portee === "string") add("Portée", capability.portee);
    }
    if (key === "nanoc") {
      add("Activation", fields(capability.activation));
      add("Durée", capability.duree);
      const creationRows = [["Simple", capability.energie?.base], ["Détaillé", capability.energie?.detaille], ["Mécanique", capability.energie?.mecanique]]
        .filter(([, cost]) => cost != null)
        .map(([name, cost]) => [escapeHtml(name), `${number(cost)} PE`]);
      if (capability.energie?.prolonger != null) creationRows.push(["Prolongation", `${number(capability.energie.prolonger)} PE`]);
      supplementalHtml = table(["Création nanoC", "Coût"], creationRows);
    }
    if (key === "mechanic") {
      const repairRows = [];
      for (const mode of ["contact", "distance"]) {
        const repair = capability.reparation?.[mode];
        if (!repair) continue;
        repairRows.push([
          escapeHtml(label(mode)),
          `${escapeHtml(formatDice(repair))}<small>${escapeHtml(repair.duree || "—")}</small>`,
          `${number(capability.energie?.[mode])} PE`,
          escapeHtml(mode === "distance" ? capability.portee || "—" : "Contact"),
        ]);
      }
      supplementalHtml = table(["Mode", "Réparation", "Coût", "Portée"], repairRows, "knight-mechanic-table");
    }
    if (key === "ghost") {
      add("Réussites bonus", capability.bonus?.reussites);
      add("Attaque", capability.bonus?.attaque);
      const damage = capability.bonus?.degats;
      if (damage) {
        const parts = [];
        if (damage.fixe) parts.push(`valeur de ${damage.caracteristique}`);
        if (damage.dice) parts.push(`dés de ${damage.caracteristique}`);
        if (damage.od) parts.push(`OD de ${damage.caracteristique}`);
        if (parts.length) add("Bonus dégâts configuré", parts.join(" + "));
      }
    }
    if (key === "goliath") {
      const maximumGain = number(capability.taille?.max);
      const energyPerMeter = number(capability.energie);
      const forcePerMeter = number(capability.bonus?.force?.value);
      const endurancePerMeter = number(capability.bonus?.endurance?.value);
      const damagePerMeter = number(capability.bonus?.degats?.dice);
      const violencePerMeter = number(capability.bonus?.violence?.dice);
      const forceFieldPerMeter = number(capability.bonus?.cdf?.value);
      const defensePerMeter = number(capability.malus?.defense?.value);
      const reactionPerMeter = number(capability.malus?.reaction?.value);
      const rackHeight = number(capability.armesRack?.value);
      if (maximumGain) add("Limite actuelle", `${2 + maximumGain} m au total (+${maximumGain} m)`);
      const tableRows = [];
      for (let gain = 1; gain <= maximumGain; gain += 1) {
        const height = 2 + gain;
        const forceBonus = forcePerMeter * gain;
        const enduranceBonus = endurancePerMeter * gain;
        const characteristicBonus = forceBonus === enduranceBonus
          ? `+${forceBonus} réussite${forceBonus > 1 ? "s" : ""} chacune`
          : `Force +${forceBonus} / Endurance +${enduranceBonus}`;
        const special = rackHeight && height >= rackHeight
          ? `${effectsHtml(["Anti-véhicule"])} · armes rackées (modules utilisables)`
          : "—";
        tableRows.push(
          `<tr><td>${height} m</td><td>${energyPerMeter * gain} PE</td><td>${characteristicBonus}<small>+${5 * gain} t soulevées</small></td><td>+${damagePerMeter * gain}D6 / +${violencePerMeter * gain}D6</td><td>+${forceFieldPerMeter * gain}</td><td>${defensePerMeter ? `−${defensePerMeter * gain}` : "—"} / ${reactionPerMeter ? `−${reactionPerMeter * gain}` : "—"}</td><td>${special}</td></tr>`,
        );
      }
      if (tableRows.length) {
        supplementalHtml = `<div class="knight-goliath-table-wrap"><table class="knight-goliath-table"><thead><tr><th>Taille</th><th>Coût</th><th>Force / Endurance</th><th>Dégâts / Violence</th><th>CdF</th><th>Déf. / Réac.</th><th>À partir de cette taille</th></tr></thead><tbody>${tableRows.join("")}</tbody></table></div>`;
      }
    }
    if (key === "longbow") {
      // These are configurable ranges, not an already-paid attack profile.
      const adjustmentRows = [];
      for (const [stat, title] of [["degats", "Dégâts"], ["violence", "Violence"]]) {
        const value = capability[stat];
        if (value?.min != null && value?.max != null) adjustmentRows.push([escapeHtml(title), `${value.min} à ${value.max}D6`, `${number(value.energie)} PE / niveau`]);
      }
      const range = capability.portee;
      if (range?.min) adjustmentRows.push(["Portée", `${escapeHtml(range.min)} à ${escapeHtml(range.max)}`, `${number(range.energie)} PE / niveau`]);
      const effectRows = [];
      for (const [effectKey, effects] of Object.entries(capability.effets ?? {})) {
        if (effects.acces === false) continue;
        const rawEffects = [...(effects.raw ?? []), ...(effects.custom ?? [])];
        if (rawEffects.length) effectRows.push([
          effectKey === "base" ? "Base" : escapeHtml(effectKey.replace("liste", "Liste ")),
          effects.energie == null ? "—" : `${number(effects.energie)} PE`,
          effectsHtml(rawEffects, " · "),
        ]);
      }
      supplementalHtml = `${table(["Réglage", "Plage actuelle", "Coût"], adjustmentRows, "knight-capability-table-wide")}${table(["Effets", "Coût", "Choix disponibles"], effectRows, "knight-capability-table-wide knight-capability-effects-table")}`;
    }
    if (key === "borealis") {
      const support = capability.support ?? {};
      const offensive = capability.offensif ?? {};
      const utility = capability.utilitaire ?? {};
      const offensiveEffects = effectsHtml(
        [...(offensive.effets?.raw ?? []), ...(offensive.effets?.custom ?? [])],
        " · ",
      );
      supplementalHtml = table(
        ["Usage", "Activation", "Durée", "Coût", "Effet"],
        [
          ["Support", escapeHtml(label(support.activation)), escapeHtml(support.duree || "—"), `${number(support.energie?.base)} PE<small>+${number(support.energie?.allie)} PE par allié supplémentaire</small>`, `${effectsHtml(["Anti-Anathème"])} sur les armes utilisées`],
          ["Offensif", escapeHtml(label(offensive.activation)), escapeHtml(offensive.duree || "—"), `${number(offensive.energie)} PE`, `${escapeHtml(formatDice(offensive.degats))} dégâts / ${escapeHtml(formatDice(offensive.violence))} violence<small>Portée ${escapeHtml(offensive.portee || "—")} · ${offensiveEffects}</small>`],
          ["Utilitaire", escapeHtml(label(utility.activation)), escapeHtml(utility.duree || "—"), `${number(utility.energie)} PE`, "Manipulation du plasma<small>Éclairage, fusion, feu ou formes simples</small>"],
        ],
        "knight-capability-table-wide",
      );
    }
    if (key === "oriflamme") {
      const rawEffects = [...(capability.effets?.raw ?? []), ...(capability.effets?.custom ?? [])];
      if (rawEffects.length) addHtml("Effets", effectsHtml(rawEffects, " · "));
    }
    if (key === "warlord") {
      const impulses = capability.impulsions ?? {};
      if (impulses.selection != null) add("Impulsions sélectionnables", impulses.selection);
      const impulseRows = [];
      const costs = (energy = {}) => Object.entries(energy)
        .filter(([, value]) => typeof value === "number")
        .map(([target, value]) => `${target === "allie" ? "Allié" : target === "porteur" ? "Porteur" : label(target)} : ${value} PE`).join(" · ");
      const impulseSummary = {
        action: "Une action de combat ou de déplacement supplémentaire",
        esquive: `Défense +${number(impulses.esquive?.bonus?.defense)} · Réaction +${number(impulses.esquive?.bonus?.reaction)}`,
        force: `CdF +${number(impulses.force?.bonus?.champDeForce)}`,
        guerre: `Dégâts +${number(impulses.guerre?.bonus?.degats)}D6 · Violence +${number(impulses.guerre?.bonus?.violence)}D6`,
        energie: `Transfert de ${number(impulses.energie?.energie?.min)} à ${number(impulses.energie?.energie?.max)} PE à un allié`,
      };
      for (const impulseKey of ["action", "esquive", "force", "guerre", "energie"]) {
        const impulse = impulses[impulseKey];
        if (!impulse) continue;
        const activation = Array.isArray(impulse.activation)
          ? [...new Set(impulse.activation.map(label))].join(" / ")
          : label(impulse.activation);
        impulseRows.push([
          escapeHtml(impulseKey.replace(/^./u, (character) => character.toLocaleUpperCase("fr"))),
          escapeHtml(activation || "—"),
          escapeHtml(impulse.duree || "—"),
          escapeHtml(impulseSummary[impulseKey] || "—"),
          escapeHtml(costs(impulse.energie) || "—"),
        ]);
      }
      supplementalHtml = table(["Impulsion", "Activation", "Durée", "Bonus", "Coût"], impulseRows, "knight-capability-table-wide");
    }
    if (key === "falcon") {
      const informationChoices = htmlToMarkdown(capability.informations || "").split(/\n+/).map((choice) => choice.trim()).filter(Boolean);
      if (informationChoices.length) {
        supplementalHtml = `<div class="knight-falcon-choices"><strong>Une information au choix :</strong><ul>${informationChoices.map((choice) => `<li>${escapeHtml(choice)}</li>`).join("")}</ul></div>`;
      }
    }
    for (const [stat, title] of [["degats", "Dégâts"], ["violence", "Violence"]]) {
      if (capability[stat]?.dice != null) add(title, formatDice(capability[stat]));
    }
    const description = htmlToMarkdown(capability.description || "");
    entries.push(`<section class="knight-trait knight-capability"><h3>${escapeHtml(capability.label || key)}</h3><div class="knight-trait-description">${description ? `<div class="knight-capability-prose">${markdownishHtml(description)}</div>` : ""}${rows.length ? `<div class="knight-capability-details">${rows.join("\n")}</div>` : ""}${supplementalHtml}</div></section>`);
  }
  return entries.length ? `<section class="knight-traits knight-capabilities" aria-label="Capacités de méta-armure">${entries.join("\n")}</section>` : "";
}

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function markdownishHtml(value = "") {
  return escapeHtml(value)
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    .replace(/\n\n/g, "</p><p>")
    .replace(/\n/g, "<br>")
    .replace(/^/, "<p>")
    .replace(/$/, "</p>");
}

function moduleFamily(name = "") {
  return name
    .replace(/\s*-?\s*niv(?:eau)?\.?\s*\d+\s*$/i, "")
    .trim()
    .toLocaleLowerCase("fr");
}

function latestModules(moduleItems) {
  const selected = new Map();
  for (const item of moduleItems) {
    const key = moduleFamily(item.name);
    const previous = selected.get(key);
    if (!previous || selectedModuleLevel(item) > selectedModuleLevel(previous)) {
      selected.set(key, item);
    }
  }
  return [...selected.values()];
}

function selectedModuleData(item) {
  const level = selectedModuleLevel(item);
  const details = item.system?.niveau?.details ?? {};
  return details[`n${level}`] ?? details[`n${item.system?.niveau?.value}`] ?? {};
}

function moduleWeaponProfile(item) {
  const weapon = selectedModuleData(item).arme;
  if (!weapon?.has) return null;
  const hasCombatValues = Boolean(
    number(weapon.degats?.dice) ||
      number(weapon.degats?.fixe) ||
      number(weapon.violence?.dice) ||
      number(weapon.violence?.fixe) ||
      weapon.degats?.variable?.has ||
      weapon.violence?.variable?.has,
  );
  if (!hasCombatValues) return null;
  return {
    name: item.name,
    system: weapon,
    arsenalUrl: moduleUrl(item.name),
  };
}

function isOverdriveModule(item) {
  const overdrives = selectedModuleData(item).overdrives;
  if (overdrives?.has) return true;
  return Object.values(overdrives?.aspects ?? {}).some((characteristics) =>
    Object.values(characteristics ?? {}).some((value) => number(value) > 0),
  );
}

function moduleMechanicalSummary(item) {
  const data = selectedModuleData(item);
  const details = [];

  if (data.permanent) details.push("Permanent");
  else {
    const energy = number(data.energie?.tour?.value);
    if (energy) details.push(`${energy} PE`);
    if (data.activation && data.activation !== "aucune") {
      details.push(`activation : ${LABELS[data.activation] ?? data.activation}`);
    }
    if (
      data.energie?.tour?.label &&
      !["Tour", "Aucune"].includes(data.energie.tour.label)
    ) {
      details.push(`durée : ${data.energie.tour.label}`);
    }
  }

  if (data.portee && data.portee !== "personnelle") details.push(`portée : ${data.portee}`);

  const bonuses = data.bonus ?? {};
  for (const [key, label] of [
    ["sante", "PS"],
    ["armure", "PA"],
    ["champDeForce", "CdF"],
    ["energie", "PE max"],
  ]) {
    if (bonuses[key]?.has && number(bonuses[key]?.value)) {
      details.push(`+${number(bonuses[key].value)} ${label}`);
    }
  }

  const overdrives = data.overdrives?.aspects ?? {};
  for (const [domain, characteristics] of Object.entries(DOMAIN_CHARACTERISTICS)) {
    for (const characteristic of characteristics) {
      const value = number(overdrives?.[domain]?.[characteristic]);
      if (value) details.push(`${LABELS[characteristic]} : OD ${value}`);
    }
  }

  if (data.bonus?.grenades?.has) {
    const grenadeBonuses = [];
    for (const [key, grenade] of Object.entries(data.bonus.grenades.liste ?? {})) {
      const damage = number(grenade.degats?.dice);
      const violence = number(grenade.violence?.dice);
      if (!damage && !violence) continue;
      const label = {
        antiblindage: "antiblindage",
        explosive: "explosive",
        shrapnel: "shrapnel",
      }[key] ?? key;
      grenadeBonuses.push(`${label} : +${damage}D6 dégâts, +${violence}D6 violence`);
    }
    if (grenadeBonuses.length) details.push(`Grenades ${grenadeBonuses.join(" ; ")}`);
  }

  const effects = [
    ...(data.arme?.effets?.raw ?? []),
    ...(data.arme?.effets?.custom ?? []),
    ...(data.effets?.raw ?? []),
    ...(data.effets?.custom ?? []),
  ];
  if (effects.length) {
    details.push(`Effets : ${effectsMarkdown(effects)}`);
  }

  return details.join(" ; ") || "Voir la description du module";
}

const armor = items.find((item) => item.type === "armure");
const distinctions = items.filter((item) => item.type === "distinction" && meaningfulItem(item));
const contacts = items.filter((item) => item.type === "contact" && item.name?.trim());
const minorMotivations = items.filter((item) => item.type === "motivationMineure");
const personalAdvantages = items.filter(
  (item) => item.type === "avantage" && item.system?.type !== "ia" && meaningfulItem(item),
);
const personalDisadvantages = items.filter(
  (item) => item.type === "inconvenient" && item.system?.type !== "ia" && meaningfulItem(item),
);
const iaAdvantages = items.filter(
  (item) => item.type === "avantage" && item.system?.type === "ia" && meaningfulItem(item),
);
const iaDisadvantages = items.filter(
  (item) => item.type === "inconvenient" && item.system?.type === "ia" && meaningfulItem(item),
);
const injuries = items.filter((item) => item.type === "blessure" && meaningfulItem(item));
const modules = latestModules(items.filter((item) => item.type === "module"));
const displayedModules = modules.filter((item) => !isOverdriveModule(item));
const weapons = [
  ...items.filter((item) => item.type === "arme" && meaningfulItem(item)),
  ...modules.map(moduleWeaponProfile).filter(Boolean),
];

const weaponGroups = new Map();
for (const weapon of weapons) {
  const baseName = weaponBaseName(weapon.name);
  const group = weaponGroups.get(baseName) ?? [];
  group.push(weapon);
  weaponGroups.set(baseName, group);
}

const progression = system.progression ?? {};
const gloryTotal = number(progression.gloire?.total);
const experienceTotal = number(progression.experience?.total);
const gloryRemaining = gloryTotal - glorySpent();
const experienceRemaining = experienceTotal - experienceSpent();
const isKraken = Boolean(system.options?.kraken);
const armorWorn = system.wear === "armure" || system.wear === "ascension";
const combatStyle = styleModifiers(system.combat?.style);

const healthMaximum = Math.max(
  0,
  (isKraken ? 8 : 6) * maxCharacteristic("chair") +
    10 +
    actorModifier("sante") +
    traitModifier("avantage", ["sante"]) -
    traitModifier("inconvenient", ["sante"]),
);
const hopeMaximum = Math.max(
  0,
  50 +
    number(armorWorn ? armor?.system?.espoir?.value : 0) +
    actorModifier("espoir") +
    traitModifier("avantage", ["espoir"]) -
    traitModifier("inconvenient", ["espoir"]),
);

function defenseFor(withArmor) {
  return Math.max(
    0,
    maxCharacteristic("bete", withArmor) +
      (isKraken ? 1 : 0) +
      actorModifier("defense") +
      weaponFlatModifier("defense") +
      combatStyle.defense,
  );
}

function reactionFor(withArmor) {
  return Math.max(
    0,
    maxCharacteristic("machine", withArmor) +
      (isKraken ? 1 : 0) +
      actorModifier("reaction") +
      weaponFlatModifier("reaction") +
      combatStyle.reaction,
  );
}

const initiativeDice = Math.max(
  0,
  number(system.initiative?.diceBase, 3) +
    items
      .filter((item) => item.type === "avantage")
      .reduce((sum, item) => sum + number(item.system?.bonus?.initiative?.dice), 0) -
    items
      .filter((item) => item.type === "inconvenient")
      .reduce((sum, item) => sum + number(item.system?.malus?.initiative?.dice), 0),
);
function initiativeFixedFor(withArmor) {
  return Math.max(
    0,
    maxCharacteristic("masque", withArmor) +
      actorModifier("initiative") +
      traitModifier("avantage", ["initiative", "fixe"]) -
      traitModifier("inconvenient", ["initiative", "fixe"]),
  );
}

const armorInitiativeFixed = initiativeFixedFor(true);
const guardianInitiativeFixed = initiativeFixedFor(false);
const armorDefense = defenseFor(true);
const guardianDefense = defenseFor(false);
const armorReaction = reactionFor(true);
const guardianReaction = reactionFor(false);
const forceField = number(armorWorn ? armor?.system?.champDeForce?.base : system.equipements?.guardian?.champDeForce?.base) + weaponFlatModifier("cdf");

const out = [];
out.push("---");
out.push(`title: ${JSON.stringify(actor.name || "Personnage")}`);
out.push("type: pj");
out.push("visibility: public");
out.push("coterie: manticore");
out.push(`portrait: ${JSON.stringify(`[[${actor.name || "Personnage"}-portrait.png]]`)}`);
out.push(`portrait-armure: ${JSON.stringify(`[[${actor.name || "Personnage"}-armure.png]]`)}`);
out.push(`archetype: ${JSON.stringify(system.archetype ?? "")}`);
out.push(`blason: ${JSON.stringify(system.blason ?? "")}`);
out.push(`section: ${JSON.stringify(system.section ?? "")}`);
out.push(`metaarmure: ${JSON.stringify(armor?.name ?? system.metaarmure ?? "")}`);
out.push("cssclasses:");
out.push("  - fiche-personnage");
out.push("---\n");
out.push('<div class="knight-sheet-marker" aria-hidden="true"></div>\n');
out.push('<section class="knight-identity">');
out.push('<div class="knight-profile">');
out.push('<div class="knight-title-line">');
out.push(`<h1>${escapeHtml(actor.name || "Personnage")}</h1>`);
const blasonName = String(system.blason ?? "").replace(/[\[\]]/g, "").trim();
const blasonLink = blasonName
  ? `<a class="internal" href="/aides-de-jeu/blasons/${slugify(blasonName)}">${escapeHtml(blasonName)}</a>`
  : "—";
const armorName = armor?.name || system.metaarmure || "";
const armorProfileLink = armorName
  ? `<strong><a href="${armorUrl(armorName)}">${escapeHtml(armorName)}</a></strong> · `
  : "";
out.push(
  `<p class="knight-profile-lead">${armorProfileLink}<strong>${escapeHtml(system.archetype || "Archétype inconnu")}</strong> · Section <strong>${escapeHtml(system.section || "—")}</strong> · Blason <strong>${blasonLink}</strong></p>`,
);
out.push("</div>");
out.push('<dl class="knight-profile-details">');
out.push(`<div><dt>Haut fait</dt><dd>${escapeHtml(system.hautFait || "—")}</dd></div>`);
out.push(
  `<div class="knight-major-motivation"><dt>Motivation majeure</dt><dd>${escapeHtml(htmlToMarkdown(system.motivations?.majeure) || "—")}</dd></div>`,
);
if (minorMotivations.length) {
  out.push('<div class="knight-minor-motivations"><dt>Motivations mineures</dt><dd><ul>');
  for (const motivation of minorMotivations) {
    out.push(`<li>${escapeHtml(htmlToMarkdown(motivation.system?.description) || "—")}</li>`);
  }
  out.push("</ul></dd></div>");
}
out.push("</dl>");
if (contacts.length) out.push(contactsSection(contacts, "screen-only knight-contacts-screen"));
out.push("</div>");
out.push('<aside class="knight-profile-side">');
const portraitFileName = `${actor.name || "Personnage"}-portrait.png`;
out.push(
  `<div class="knight-portrait"><img src="../__images/pj/${encodeURIComponent(portraitFileName)}" alt="Portrait de ${escapeHtml(actor.name)}"></div>`,
);
out.push('<div class="knight-progression" aria-label="Progression">');
out.push(`<span><strong>PG</strong> ${gloryRemaining} / ${gloryTotal}</span>`);
out.push(`<span><strong>PX</strong> ${experienceRemaining} / ${experienceTotal}</span>`);
out.push("</div>");
out.push('<div class="knight-progression knight-personal-points" aria-label="Points de contact et d’héroïsme">');
out.push(`<span class="knight-ph"><strong title="Points d’héroïsme">PH</strong> ${number(system.heroisme?.value)} / ${number(system.heroisme?.max)}</span>`);
out.push(`<span class="knight-pc"><strong title="Points de contact">PC</strong> ${escapeHtml(system.contacts?.actuel ?? "—")}</span>`);
out.push("</div>");
out.push("</aside>");
out.push("</section>");

out.push("\n");
out.push('<div class="knight-combat-grid">');
out.push('<div class="knight-stat-table">');
out.push('<div class="knight-stat-cells">');
out.push(`<div><span>PS</span><strong>${healthMaximum}</strong></div>`);
out.push(`<div><span>PEs</span><strong>${number(system.espoir?.value)} / ${hopeMaximum}</strong></div>`);
out.push(`<div><span>PA</span><strong>${number(armor?.system?.armure?.base) || "—"}</strong></div>`);
out.push(`<div><span>PE</span><strong>${number(armor?.system?.energie?.base) || "—"}</strong></div>`);
out.push(`<div><span>CdF</span><strong>${forceField}</strong></div>`);
out.push("</div>");
out.push("</div>");
out.push('<div class="knight-stat-table">');
const armorInitiative = `${initiativeDice}D6${armorInitiativeFixed ? ` + ${armorInitiativeFixed}` : ""}`;
const guardianInitiative = `${initiativeDice}D6${guardianInitiativeFixed ? ` + ${guardianInitiativeFixed}` : ""}`;
out.push('<div class="knight-stat-cells knight-combat-cells">');
out.push(`<div><span>Défense</span><strong>${armorDefense} / ${guardianDefense}</strong></div>`);
out.push(`<div><span>Réaction</span><strong>${armorReaction} / ${guardianReaction}</strong></div>`);
out.push(`<div class="knight-initiative-cell"><span>Initiative</span><strong>${armorInitiative === guardianInitiative ? armorInitiative : `${armorInitiative} / ${guardianInitiative}`}</strong></div>`);
out.push("</div>");
out.push("</div>");
out.push("</div>");

out.push("\n## Aspects, caractéristiques et overdrives\n");
out.push('<div class="knight-domain-grid">');
for (const [domain, characteristics] of Object.entries(DOMAIN_CHARACTERISTICS)) {
  out.push('<section class="knight-domain">');
  out.push(`<h3>${escapeHtml(LABELS[domain])} — ${domainValue(domain)}</h3>`);
  out.push('<div class="knight-characteristics">');
  for (const characteristic of characteristics) {
    out.push(
      `<div class="knight-characteristic"><span>${escapeHtml(LABELS[characteristic])}</span><strong>${characteristicValue(domain, characteristic)}</strong><small>OD ${overdriveValue(domain, characteristic)}</small></div>`,
    );
  }
  out.push("</div></section>");
}
if (contacts.length) out.push(contactsSection(contacts, "print-only knight-contacts-print"));
out.push("</div>");

const nods = system.combat?.nods ?? {};
const availableNods = [
  ["Soin", nods.soin],
  ["Armure", nods.armure],
  ["Énergie", nods.energie],
].filter(([, nod]) => number(nod?.max) > 0);
const grenadeMaximum = number(system.combat?.grenades?.quantity?.max);
if (availableNods.length || grenadeMaximum > 0) {
  out.push('<div class="knight-nods"><strong>NODs</strong>');
  for (const [label, nod] of availableNods) {
    out.push(`<span>${label} <b>${escapeHtml(nod.dices || "—")}</b><em class="knight-counter" aria-label="${number(nod.max)} utilisations">${checkBoxes(nod.max)}</em></span>`);
  }
  if (grenadeMaximum > 0) {
    out.push(`<span class="knight-grenade-counter">Grenades <em class="knight-counter" aria-label="${grenadeMaximum} grenades">${checkBoxes(grenadeMaximum)}</em></span>`);
  }
  out.push("</div>");
}

if (personalAdvantages.length) out.push(`\n${traitSection("Avantages", personalAdvantages)}`);
if (personalDisadvantages.length) out.push(`\n${traitSection("Inconvénients", personalDisadvantages)}`);

if (distinctions.length) {
  // Display conditional effects without adding them to permanent statistics.
  const cards = distinctions.map((item) => {
    const bonuses = [];
    for (const [key, label] of [["espoir", "Espoir"], ["egide", "Égide"]]) {
      const value = number(item.system?.[key]);
      if (value) bonuses.push(`${label} : ${value > 0 ? "+" : ""}${value}`);
    }
    return { ...item, system: { ...item.system, description: `${item.system?.description || ""}${bonuses.length ? `<p><strong>Bonus renseignés :</strong> ${bonuses.join(" ; ")}</p>` : ""}` } };
  });
  out.push(`\n${traitSection("Distinctions", cards)}`);
}

if (weaponGroups.size || grenadeMaximum > 0) out.push(`\n${arsenalSection(weaponGroups)}\n`);

out.push(`\n## Méta-armure — ${armor?.name || system.metaarmure || "—"}\n`);
if (armor?.system?.description) {
  out.push(
    `<div class="screen-only">${markdownishHtml(htmlToMarkdown(armor.system.description).split("\n\n")[0])}</div>\n`,
  );
}

out.push(armorEvolutionsSection(armor));
out.push(armorCapabilitiesSection(armor));

if (displayedModules.length) {
  out.push('<h3 class="knight-equipment-title">Modules</h3>\n');
  out.push("| Module | Niveau | Effets essentiels |");
  out.push("|---|:---:|---|");
  for (const module of displayedModules) {
    const level = selectedModuleLevel(module);
    const name = moduleFamily(module.name).replace(/^./u, (c) => c.toLocaleUpperCase("fr"));
    out.push(
      `| [${escapeCell(name)} ↗](${moduleUrl(module.name)}) | ${level || "—"} | ${escapeCell(moduleMechanicalSummary(module))} |`,
    );
  }
}

const ia = system.equipements?.ia ?? {};
if (ia.surnom || ia.code || ia.caractere || iaAdvantages.length || iaDisadvantages.length) {
  out.push(`\n### IA de la méta-armure — ${ia.surnom || "Sans surnom"}\n`);
  out.push(`**Nom de code :** ${ia.code || "—"}\n`);
  if (ia.caractere) {
    out.push(
      `<blockquote class="knight-ia-character">${markdownishHtml(htmlToMarkdown(ia.caractere))}</blockquote>\n`,
    );
  }
  if (iaAdvantages.length) out.push(`\n${traitSection("Avantages de l’IA", iaAdvantages)}`);
  if (iaDisadvantages.length) out.push(`\n${traitSection("Inconvénients de l’IA", iaDisadvantages)}`);
}

if (injuries.length) {
  out.push("\n## Blessures\n");
  for (const injury of injuries) {
    out.push(`### ${injury.name}\n\n${htmlToMarkdown(injury.system?.description) || "—"}\n`);
  }
}

out.push(`\n<div class="screen-only knight-generation-note"><hr><p><em>Fiche générée depuis un export Foundry VTT — système Knight ${escapeHtml(actor._stats?.systemVersion ?? "version inconnue")}.</em></p></div>`);
out.push('\n<div class="screen-only knight-print-actions"><button type="button" class="knight-print-button" onclick="window.print()" aria-label="Imprimer la fiche">🖨 Imprimer la fiche</button></div>');

function yamlString(value) {
  return JSON.stringify(String(value ?? ""));
}

function statblockTraits(lines, key, selectedItems, descriptionCallback = null, nameCallback = null) {
  if (!selectedItems.length) return;
  lines.push(`${key}:`);
  for (const item of selectedItems) {
    const description = descriptionCallback
      ? descriptionCallback(item)
      : htmlToMarkdown(item.system?.description) || mechanicalSummary(item) || "";
    const name = nameCallback ? nameCallback(item) : item.name || "—";
    lines.push(`  - name: ${yamlString(name)}`);
    if (description) lines.push(`    desc: ${yamlString(description)}`);
  }
}

function characteristicDisplay(domain, characteristic) {
  const value = characteristicValue(domain, characteristic);
  const od = overdriveValue(domain, characteristic);
  return od ? `${value} (${od})` : String(value);
}

function pjStatblock(layout) {
  const armorName = armor?.name || system.metaarmure || "";
  const realName = [system.prenom, system.nom].filter(Boolean).join(" ") || system.identite || "";
  const armorForceField = number(armor?.system?.champDeForce?.base) + weaponFlatModifier("cdf");
  const guardianForceField = number(system.equipements?.guardian?.champDeForce?.base) + weaponFlatModifier("cdf");
  const lines = [
    "```statblock",
    `layout: ${layout}`,
    "columns: 2",
    "columnWidth: 350",
    "forceColumns: true",
    `name: ${yamlString(actor.name || "Personnage")}`,
  ];
  if (realName) lines.push(`realname: ${yamlString(realName)}`);
  lines.push("type: pj");
  lines.push("coterie: Manticore");
  if (system.section) lines.push(`section: ${yamlString(system.section)}`);
  if (armorName) lines.push(`méta-armure: ${yamlString(`[[${armorName}]]`)}`);
  if (system.blason) lines.push(`blason: ${yamlString(`[[${system.blason}]]`)}`);

  lines.push(`defense: ${yamlString(`${armorDefense}/${guardianDefense}`)}`);
  lines.push(`reaction: ${yamlString(`${armorReaction}/${guardianReaction}`)}`);
  lines.push(`initiative: ${yamlString(`${armorInitiative}/${guardianInitiative}`)}`);
  lines.push(`pc: ${number(system.contacts?.actuel)}`);
  lines.push(`pg: ${yamlString(`${gloryRemaining}/${gloryTotal}`)}`);
  lines.push(`px: ${yamlString(`${experienceRemaining}/${experienceTotal}`)}`);
  lines.push(`ph: ${yamlString(`${number(system.heroisme?.value)}/${number(system.heroisme?.max)}`)}`);
  lines.push(`ps: ${healthMaximum}`);
  lines.push(`pes: ${yamlString(`${number(system.espoir?.value)}/${hopeMaximum}`)}`);
  lines.push(`cdf: ${yamlString(`${armorForceField}/${guardianForceField}`)}`);
  lines.push(`pa: ${number(armor?.system?.armure?.base)}`);
  lines.push(`pe: ${number(armor?.system?.energie?.base)}`);

  if (layout === "Knight PJ") {
    lines.push(`aspects: [${["chair", "bete", "machine", "dame", "masque"].map(domainValue).join(", ")}]`);
    for (const [domain, characteristics] of Object.entries(DOMAIN_CHARACTERISTICS)) {
      for (const characteristic of characteristics) {
        const key = LABELS[characteristic].toLocaleLowerCase("fr");
        lines.push(`${key}: ${yamlString(characteristicDisplay(domain, characteristic))}`);
      }
    }
    const armorCapabilities = Object.values(armor?.system?.capacites?.selected ?? {}).map((capability) => ({
      name: capability.label || capability.key,
      system: { description: capability.description || "" },
    }));
    statblockTraits(lines, "skills", armorCapabilities);
    statblockTraits(lines, "modules", displayedModules, moduleMechanicalSummary);
    statblockTraits(lines, "armes", weapons, (weapon) => {
      const effects = [...(weapon.system?.effets?.raw ?? []), ...(weapon.system?.effets?.custom ?? [])];
      return [
        `Type : ${weapon.system?.type || "—"}`,
        `Portée : ${weapon.system?.portee || "—"}`,
        `Dégâts : ${formatDice(weapon.system?.degats)}`,
        `Violence : ${formatDice(weapon.system?.violence)}`,
        effects.length ? `Effets : ${effectsMarkdown(effects)}` : "",
      ].filter(Boolean).join(" · ");
    });
  }

  const summaryNamesOnly = layout === "Knight PJ Summary" ? () => "" : null;
  const traitWikiLink = (item) => `[[${item.name || "—"}]]`;
  statblockTraits(lines, "avantages", personalAdvantages, summaryNamesOnly, traitWikiLink);
  statblockTraits(lines, "inconvénients", personalDisadvantages, summaryNamesOnly, traitWikiLink);
  if (layout === "Knight PJ Summary") {
    const motivations = [
      ...(system.motivations?.majeure ? [{ name: "Motivation majeure", system: { description: system.motivations.majeure } }] : []),
      ...minorMotivations.map((item, index) => ({
        name: item.name && item.name !== "Motivation Mineure" ? item.name : `Motivation mineure ${index + 1}`,
        system: { description: item.system?.description || "" },
      })),
    ];
    statblockTraits(lines, "motivations", motivations);
  }
  lines.push("```");
  return lines.join("\n");
}

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, `${out.join("\n").replace(/\n{4,}/g, "\n\n\n")}\n`, "utf8");
console.log(`Fiche générée : ${outputPath}`);

if (mjOutputArgument) {
  const mjOutputPath = path.resolve(mjOutputArgument.slice("--mj-output=".length));
  fs.mkdirSync(path.dirname(mjOutputPath), { recursive: true });
  const frontmatter = [
    "---",
    "type: fiche",
    "subtype: pj",
    `pj: ${yamlString(actor.name || "Personnage")}`,
    `nom: ${yamlString(actor.name || "Personnage")}`,
    "---",
    "",
  ].join("\n");
  fs.writeFileSync(mjOutputPath, `${frontmatter}${pjStatblock("Knight PJ")}\n`, "utf8");
  console.log(`Fiche MJ générée : ${mjOutputPath}`);
}

if (summaryOutputArgument) {
  const summaryOutputPath = path.resolve(summaryOutputArgument.slice("--summary-output=".length));
  fs.mkdirSync(path.dirname(summaryOutputPath), { recursive: true });
  fs.writeFileSync(summaryOutputPath, `${pjStatblock("Knight PJ Summary")}\n`, "utf8");
}

// Permet aussi d'importer ce fichier depuis un autre script.
export { htmlToMarkdown, slugify, weaponBaseName, weaponUrl };
